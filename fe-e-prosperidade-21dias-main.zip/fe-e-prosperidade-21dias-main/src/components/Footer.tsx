export const Footer = () => {
  return (
    <footer className="py-6 bg-muted/30 border-t border-border/50">
      <div className="container mx-auto px-4">
        <div className="text-center text-xs sm:text-sm text-muted-foreground">
          <p className="mb-2 px-4">
            © 2025 21 Dias de Oração para Destravar a Prosperidade
          </p>
          <p className="leading-relaxed px-4">
            Conectando você com Deus, fortalecendo sua fé e abrindo caminhos para uma vida plena e próspera.
          </p>
        </div>
      </div>
    </footer>
  );
};
