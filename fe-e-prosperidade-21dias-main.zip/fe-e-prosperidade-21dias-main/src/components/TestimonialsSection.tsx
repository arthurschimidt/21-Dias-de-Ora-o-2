import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Mariana S.",
    role: "Empreendedora",
    content: "No 7º dia, algo mudou dentro de mim. Comecei a ver oportunidades onde antes só via dificuldade.",
    rating: 5
  },
  {
    name: "Carlos Mendes",
    role: "Empresário",
    content: "Aprendi que prosperidade vai além do financeiro. Hoje vivo em abundância espiritual e material!",
    rating: 5
  },
  {
    name: "Ana Paula R.",
    role: "Professora",
    content: "Depois dos 21 dias, recebi uma promoção inesperada. A fé move montanhas!",
    rating: 5
  }
];

export const TestimonialsSection = () => {
  return (
    <section className="py-12 sm:py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold mb-3 text-foreground px-2">
            Vidas Transformadas
          </h2>
          <p className="text-sm sm:text-base text-muted-foreground max-w-xl mx-auto px-4">
            Veja o que pessoas como você alcançaram através da fé e oração
          </p>
        </div>

        <div className="space-y-4 max-w-lg mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index}
              className="border border-primary/10 bg-gradient-to-br from-card to-accent/30"
            >
              <CardContent className="p-5">
                <div className="flex gap-1 mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                  ))}
                </div>
                
                <p className="text-foreground mb-4 italic leading-relaxed text-sm">
                  "{testimonial.content}"
                </p>
                
                <div className="border-t border-border/50 pt-3">
                  <p className="font-semibold text-foreground text-sm">{testimonial.name}</p>
                  <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
