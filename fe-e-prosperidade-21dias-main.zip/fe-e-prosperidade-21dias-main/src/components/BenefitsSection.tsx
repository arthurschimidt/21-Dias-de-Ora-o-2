import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Heart, Download, Lightbulb, DoorOpen } from "lucide-react";

const benefits = [
  {
    icon: BookOpen,
    title: "Orações Diárias",
    description: "21 orações poderosas para cada dia"
  },
  {
    icon: Heart,
    title: "Versículos e Reflexões",
    description: "Mensagens bíblicas profundas sobre prosperidade"
  },
  {
    icon: Download,
    title: "Acesso Imediato",
    description: "Material em PDF para baixar e começar agora"
  },
  {
    icon: Lightbulb,
    title: "Paz e Clareza",
    description: "Fortaleça sua fé e propósito divino"
  },
  {
    icon: DoorOpen,
    title: "Portas Abertas",
    description: "Veja as bênçãos fluírem ao alinhar sua fé com Deus"
  }
];

export const BenefitsSection = () => {
  return (
    <section className="py-12 sm:py-16 bg-gradient-to-b from-background to-accent">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8 sm:mb-12 animate-fade-in">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4 text-foreground px-2">
            Transforme Sua Vida em 21 Dias
          </h2>
          <p className="text-sm sm:text-base text-muted-foreground max-w-2xl mx-auto leading-relaxed px-4">
            Um guia espiritual completo para destravar a prosperidade através da oração, 
            fortalecer sua fé e atrair as bênçãos que Deus preparou para você.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 max-w-lg mx-auto">
          {benefits.map((benefit, index) => (
            <Card 
              key={index}
              className="border-border/50 bg-card/50 backdrop-blur-sm"
            >
              <CardContent className="p-5 flex items-start gap-4">
                <div className="flex-shrink-0 p-3 rounded-full bg-primary/10">
                  <benefit.icon className="w-6 h-6 text-primary" />
                </div>
                <div className="text-left">
                  <h3 className="text-base font-semibold mb-1 text-foreground">
                    {benefit.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {benefit.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
