import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles } from "lucide-react";
import heroImage from "@/assets/hero-prayer.jpg";
import jesusFamily from "@/assets/jesus-family.png";

export const HeroSection = () => {
  return (
    <section className="relative min-h-[100svh] flex items-center justify-center overflow-hidden">
      {/* Background Image com Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/90 to-background/95" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-12 text-center animate-fade-in">
        <Badge className="mb-4 bg-primary/10 text-primary border-primary/20 hover:bg-primary/20 text-xs px-3 py-1">
          <Sparkles className="w-3 h-3 mr-1" />
          Transformação em 21 Dias
        </Badge>

        {/* Imagem acima do título */}
        <div className="mb-6 flex justify-center">
          <img 
            src={jesusFamily} 
            alt="Jesus com família em oração" 
            className="w-64 h-64 object-cover rounded-2xl shadow-lg"
          />
        </div>

        <h1 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-primary via-primary to-secondary bg-clip-text text-transparent leading-tight px-2">
          21 Dias de Oração para Destravar a Prosperidade
        </h1>

        <p className="text-base sm:text-lg text-muted-foreground mb-6 max-w-2xl mx-auto leading-relaxed px-4">
          Transforme sua vida com um plano espiritual poderoso de 21 dias de fé, foco e abundância.
        </p>

        {/* Pricing */}
        <div className="mb-6">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-4">
            <span className="text-lg sm:text-xl text-muted-foreground line-through">
              De R$ 59,90
            </span>
            <span className="text-4xl sm:text-5xl font-bold text-primary">
              Por R$ 19,90
            </span>
          </div>
        </div>

        {/* CTA Button */}
        <Button 
          variant="hero" 
          size="xl"
          className="mb-4 w-full max-w-md mx-auto text-base sm:text-lg px-6"
          onClick={() => window.open('https://pay.kiwify.com.br/SFL2mGL', '_blank')}
        >
          💛 Compre Agora e Comece Hoje
        </Button>

        {/* Guarantee Badge */}
        <div className="flex items-center justify-center gap-2 text-xs sm:text-sm text-muted-foreground px-4">
          <Badge variant="outline" className="border-secondary text-secondary text-xs px-2 py-1">
            ✓ Garantia de 7 dias!
          </Badge>
        </div>
      </div>
    </section>
  );
};
