import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, Clock } from "lucide-react";

export const OfferSection = () => {
  return (
    <section className="py-12 sm:py-16 bg-gradient-to-b from-background via-accent/50 to-background relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-secondary/5 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <Badge className="mb-4 bg-destructive/10 text-destructive border-destructive/20 animate-pulse text-xs px-3 py-1">
            <Clock className="w-3 h-3 mr-1" />
            Tempo Limitado
          </Badge>

          <h2 className="text-2xl sm:text-3xl font-bold mb-4 text-foreground px-2">
            Comece Sua Jornada Espiritual Agora!
          </h2>

          <p className="text-base sm:text-lg text-muted-foreground mb-6 leading-relaxed px-4">
            Oferta especial! De <span className="line-through">R$59,90</span> por apenas{" "}
            <span className="text-2xl sm:text-3xl font-bold text-primary block mt-2">R$19,90</span>
          </p>

          <p className="text-sm sm:text-base text-muted-foreground mb-6 px-4">
            Acesso vitalício a todo o material em PDF!
          </p>

          <Button 
            variant="hero" 
            size="xl"
            className="mb-6 w-full max-w-md mx-auto text-base sm:text-lg px-6"
            onClick={() => window.open('https://pay.kiwify.com.br/SFL2mGL', '_blank')}
          >
            💛 Compre Agora e Destrave Sua Prosperidade
          </Button>

          {/* Trust Badges */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-6 px-4">
            <Badge variant="outline" className="border-secondary text-secondary px-3 py-1.5 text-xs">
              <Shield className="w-3 h-3 mr-1" />
              Compra Segura
            </Badge>
            <Badge variant="outline" className="border-primary text-primary px-3 py-1.5 text-xs">
              ✓ Garantia 7 Dias
            </Badge>
            <Badge variant="outline" className="border-secondary text-secondary px-3 py-1.5 text-xs">
              Acesso Imediato
            </Badge>
          </div>
        </div>
      </div>
    </section>
  );
};
