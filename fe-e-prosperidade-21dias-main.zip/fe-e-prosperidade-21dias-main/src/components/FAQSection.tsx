import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Como vou receber o manual?",
    answer: "Imediatamente após a confirmação do pagamento, você receberá um e-mail com o link para download do PDF. O acesso é instantâneo e vitalício."
  },
  {
    question: "Posso imprimir o manual?",
    answer: "Sim! O PDF pode ser impresso para que você possa fazer suas anotações e ter sempre à mão durante seus momentos de oração."
  },
  {
    question: "Como funciona a garantia de 7 dias?",
    answer: "Se por qualquer motivo você não ficar satisfeito, basta solicitar o reembolso em até 7 dias após a compra. Devolvemos 100% do seu investimento, sem perguntas."
  },
  {
    question: "Preciso ter experiência com orações?",
    answer: "Não! O manual foi criado para pessoas de todos os níveis de experiência espiritual. Cada oração é guiada e acompanhada de reflexões que facilitam a conexão com Deus."
  },
  {
    question: "Quanto tempo leva cada dia?",
    answer: "Reserve entre 15 a 30 minutos por dia. É um momento especial para você se conectar com Deus, refletir e fortalecer sua fé."
  },
  {
    question: "O pagamento é seguro?",
    answer: "Sim! Utilizamos plataformas de pagamento certificadas e 100% seguras. Seus dados estão totalmente protegidos."
  }
];

export const FAQSection = () => {
  return (
    <section className="py-12 sm:py-16 bg-accent">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold mb-3 text-foreground px-2">
            Perguntas Frequentes
          </h2>
          <p className="text-sm sm:text-base text-muted-foreground px-4">
            Tire suas dúvidas sobre o manual de oração
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-card border border-border/50 rounded-lg px-4 shadow-sm"
              >
                <AccordionTrigger className="text-left text-sm sm:text-base font-semibold text-foreground hover:text-primary py-4">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed pb-4">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};
